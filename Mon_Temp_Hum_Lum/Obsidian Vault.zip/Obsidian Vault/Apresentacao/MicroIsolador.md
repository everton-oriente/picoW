Fazer a apresentacao do que o nosso microisolador pode fazer se baseando no formato da apresentacao do resistor que esta contida dentro desta pasta.

[[Smart Vivarium 5.0]]

[[Resistor_1751447583.pdf]]