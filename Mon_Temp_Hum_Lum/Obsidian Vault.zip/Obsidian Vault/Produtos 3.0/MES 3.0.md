[[SCADA 2.0]]
[[ERP 4.0]]

Aqui sera feito o desenvolvimento do software que vai ter a capacidade de MES.