[[SCADA 2.0]]

Desenvolvimento de um IIoT com capacidade de comunicar via protocolo modbus tcp/ip para que entregue as informacoes no SCADA.

Requisitos

Envio de informação a cada 15 minutos para monitoramento
Funcionar de forma ininterrupta, mesmo com a falta de alimentação por 24horas
Resistir a roedores
Material não toxico
Não ter elevado ruido acima de x decibéis
Alimentado a bateria e/ou Alimentação tomada

Hardware
Raspberry pi pico 2W (CYW43 - Modulo wifi)

DHT22 (one wire protocol) Resistor PullUp 10kOhm between VCC and Data. and between vcc and GND a capacitor of 100nF.

LDR (ADC)

Software
Embassy framework
Embassy net
MQTT

Porem os pinos que sao utilizados para o uso do wifi sao

p.pin23 - power control
p.pin24 - SPI MOSI
p.pin25 - SPI Chip Select
p.pin29 - SPI SCLK


![[Diagram.svg]]



