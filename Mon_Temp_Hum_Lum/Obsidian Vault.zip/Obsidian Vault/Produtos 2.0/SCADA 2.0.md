[[MES 3.0]]

O desenvolvimento do scada se dará pelo dashboard thingsboard, aonde as features necessária para o desenvolvimento do projeto, nele temos os protocolos modbus tcp/ip, CoAP e MQTT, que são essenciais para a nossa aplicação neste momento, com isso faremos o desenvolvimento através deste scada utilizando o protocolo MQTT.


