[[MES 3.0]]

ERP  se chama Crabby, este por sua vez hoje já esta desenvolvido em visual basic, porem por ser uma framework muito ultrapassada iniciaremos o seu desenvolvimento numa framework mais nova, rápida e elegante que o VB.

Neste momento estamos com algumas alternativas como o makepad em Rust e também temos o Kivy em Python. Porem também foi descoberto que e possível misturar o Kivy com o Rust, e dentre as opções me parece a mais sensata neste momento, pois será possível separar mais tranquilo na minha mente e do meu pai as funções entre o que aparece na tela e o que acontece por trás da tela. também não foi fácil usar o Kivy com Rust.

Depois de muita pesquisa foi decidido prosseguir com Slint, e uma ferramenta muito boa para o proposito e também serve para o desenvolvimento de sistemas embarcados com GUI. Existe tutoriais, tem os itens básicos que necessitamos para o desenvolvimento do ERP Crabby. A única pendencia que fica deste uso da GUI Slint e se e precisa pagar licença se for usar com sistemas embarcados, para desktop e mobile fica claro que não existe custo nenhum, porem para embarcados não fica muito bem entendido se e possível usar a licença MIT ou Apache2.0 ao invés da que cobra royalties.

Depois de muita pesquisa decidimos prosseguir com o dioxus aonde e possível compilar para todas as plataformas desktop e mobile e com isso nos dando um leque muito grande aonde podemos descarregar os programas e desenvolver os nosso próprios software de UI, como HMI.

