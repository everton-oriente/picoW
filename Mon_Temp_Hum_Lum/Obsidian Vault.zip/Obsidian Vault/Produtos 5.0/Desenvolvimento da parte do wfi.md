[[Smart Vivarium 5.0]]

Olhar o projeto no github

https://github.com/JurajSadel/esp32c3-no-std-async-mqtt-demo

