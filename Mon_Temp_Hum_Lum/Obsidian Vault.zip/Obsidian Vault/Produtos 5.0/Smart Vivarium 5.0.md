This project was developed with the purpose of promoting improved animal welfare and advancing the processes of data acquisition in research and testing involving laboratory animals. Its core objective is to ensure ethical treatment while enhancing the reliability and efficiency of scientific data collection.

By introducing Industry 4.0 concepts into animal research facilities (bioteriums), this initiative aligns the sector with the ongoing technological transformation seen across other industries worldwide. Through automation, data integration, and smart monitoring systems, the project enables more effective use of resources such as personnel, feed, and equipment.

Ultimately, this approach contributes to more precise and efficient research practices, resulting in higher-quality outcomes in clinical trials, including implant testing, while maintaining a strong commitment to animal care and scientific integrity.

The aim of thhis project is to have all the stages in one project, the project Smart Vivarium 5.0

The composition of the stage 1.0 to 4.0 is the whole project and the aim we have.


[[ERP 4.0]]





